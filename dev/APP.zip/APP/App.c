//
// Created by dxxdx on 2026/7/23.
//

#include "App.h"

#include "app/echo.h"


const LocalShellApplication appPool[5] =
{
    ECHO_APPLICATION_INITIALIZER
};







